#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <utility>
#include "Postulante.h"
#include "EvaluadorBeca.h"
#include "MetricaAcademica.h"
#include "MetricaSocioeconomica.h"
#include "MetricaBonificacion.h"

using namespace std;

/* ==================== DECLARACION DE FUNCIONES ==================== */

bool leerPostulantesDesdeArchivo(const string& nombreArchivo,
                                 vector<Postulante>& postulantes);

void crearMetricasEvaluacion(EvaluadorBeca& evaluador);

void evaluarPostulantes(vector<Postulante>& postulantes,
                         const EvaluadorBeca& evaluador);

void ordenarPorBurbuja(vector<Postulante>& postulantes);

void mostrarRanking(const vector<Postulante>& postulantes);

/* ==================== FUNCION PRINCIPAL ==================== */

int main() {
    vector<Postulante> postulantes;

    if (!leerPostulantesDesdeArchivo("postulantes.txt", postulantes)) {
        cout << "No se pudo cargar el archivo de postulantes."<<endl;
        return 1;
    }

    EvaluadorBeca evaluador;
    crearMetricasEvaluacion(evaluador);

    evaluarPostulantes(postulantes, evaluador);
    ordenarPorBurbuja(postulantes);
    mostrarRanking(postulantes);

    return 0;
}

/* ==================== DEFINICION DE FUNCIONES ==================== */

bool leerPostulantesDesdeArchivo(const string& nombreArchivo,
                                 vector<Postulante>& postulantes) {
    ifstream archivo(nombreArchivo);
    if (!archivo.is_open())
        return false;

    string linea;
    getline(archivo, linea); // cabecera

    while (getline(archivo, linea)) {
        stringstream ss(linea);
        string dni, promedio, condicion, discapacidad, rural;

        getline(ss, dni, ',');
        getline(ss, promedio, ',');
        getline(ss, condicion, ',');
        getline(ss, discapacidad, ',');
        getline(ss, rural, ',');

        Postulante p(
            dni,
            stod(promedio),
            condicion,
            discapacidad == "Si",
            rural == "Si"
        );

        postulantes.push_back(p);
    }

    archivo.close();
    return true;
}

void crearMetricasEvaluacion(EvaluadorBeca& evaluador) {
    evaluador.agregarMetrica(new MetricaAcademica());
    evaluador.agregarMetrica(new MetricaSocioeconomica());
    evaluador.agregarMetrica(new MetricaBonificacion());
}

void evaluarPostulantes(vector<Postulante>& postulantes,
                         const EvaluadorBeca& evaluador) {
    for (auto& p : postulantes) {
        evaluador.evaluar(p);
    }
}

void ordenarPorBurbuja(vector<Postulante>& postulantes) {
    int n = postulantes.size();

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (postulantes[j].getPuntajeTotal() <
                postulantes[j + 1].getPuntajeTotal()) {
                swap(postulantes[j], postulantes[j + 1]);
            }
        }
    }
}

void mostrarRanking(const vector<Postulante>& postulantes) {
    cout <<endl<<"RANKING FINAL BECA 18"<<endl;
    cout << "----------------------"<<endl;

    int posicion = 1;
    for (const auto& p : postulantes) {
        cout << posicion++ << ". DNI: " << p.getDni()
             << " | Puntaje Total: "
             << p.getPuntajeTotal() << endl;
    }
}
