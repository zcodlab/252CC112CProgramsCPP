#ifndef EVALUADORBECA_H
#define EVALUADORBECA_H
#include <vector>
#include "MetricaEvaluacion.h"

class EvaluadorBeca {
private:
    std::vector<MetricaEvaluacion*> metricas;

public:
    void agregarMetrica(MetricaEvaluacion* m) {
        metricas.push_back(m);
    }

    void evaluar(Postulante& p) const {
        for (auto m : metricas) {
            p.agregarPuntaje(m->calcular(p));
        }
    }

    ~EvaluadorBeca() {
        for (auto m : metricas)
            delete m;
    }
};

#endif // EVALUADORBECA_H
