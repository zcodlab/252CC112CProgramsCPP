#ifndef METRICAEVALUACION_H
#define METRICAEVALUACION_H
#include "Postulante.h"

class MetricaEvaluacion {
public:
    virtual double calcular(const Postulante& p) const = 0;
    virtual std::string nombre() const = 0;
    virtual ~MetricaEvaluacion() {}
};
#endif // METRICAEVALUACION_H
