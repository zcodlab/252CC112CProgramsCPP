#ifndef METRICABONIFICACION_H
#define METRICABONIFICACION_H
#include "MetricaEvaluacion.h"

class MetricaBonificacion : public MetricaEvaluacion {
public:
    double calcular(const Postulante& p) const override {
        double bonus = 0.0;
        if (p.tieneDiscapacidad()) bonus += 10.0;
        if (p.esRural()) bonus += 10.0;
        return bonus;
    }

    std::string nombre() const override {
        return "Bonificaciones";
    }
};

#endif // METRICABONIFICACION_H
