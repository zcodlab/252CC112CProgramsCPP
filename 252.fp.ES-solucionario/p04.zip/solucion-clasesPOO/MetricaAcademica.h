#ifndef METRICAACADEMICA_H
#define METRICAACADEMICA_H
#include "MetricaEvaluacion.h"

class MetricaAcademica : public MetricaEvaluacion {
public:
    double calcular(const Postulante& p) const override {
        return (p.getPromedio() / 20.0) * 50.0; // hasta 50 puntos
    }

    std::string nombre() const override {
        return "Puntaje Academico";
    }
};
#endif // METRICAACADEMICA_H
