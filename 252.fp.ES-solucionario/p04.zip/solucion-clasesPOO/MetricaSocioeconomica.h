#ifndef METRICASOCIOECONOMICA_H
#define METRICASOCIOECONOMICA_H
#include "MetricaEvaluacion.h"

class MetricaSocioeconomica : public MetricaEvaluacion {
public:
    double calcular(const Postulante& p) const override {
        if (p.getCondicion() == "PobreExtremo")
            return 30.0;
        if (p.getCondicion() == "Pobre")
            return 20.0;
        return 0.0;
    }

    std::string nombre() const override {
        return "Puntaje Socioeconomico";
    }
};

#endif // METRICASOCIOECONOMICA_H
