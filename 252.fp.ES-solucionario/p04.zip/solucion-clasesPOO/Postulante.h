#ifndef POSTULANTE_H
#define POSTULANTE_H
#include <string>

class Postulante {
private:
    std::string dni;
    double promedio;
    std::string condicion;
    bool discapacidad;
    bool rural;
    double puntajeTotal;

public:
    Postulante(std::string d, double p, std::string c, bool disc, bool r)
        : dni(d), promedio(p), condicion(c),
          discapacidad(disc), rural(r), puntajeTotal(0) {}

    // getters
    std::string getDni() const { return dni; }
    double getPromedio() const { return promedio; }
    std::string getCondicion() const { return condicion; }
    bool tieneDiscapacidad() const { return discapacidad; }
    bool esRural() const { return rural; }

    void agregarPuntaje(double p) { puntajeTotal += p; }
    double getPuntajeTotal() const { return puntajeTotal; }
};

#endif // POSTULANTE_H
